
<div class="col-md12">
	<div id="gantt">
		<?php echo $gantt; ?>
	</div>
</div>
<div class="row">
	<div class="col-md-6">
		<h3>Progress</h3>
		<div class="col-content">
			
		</div>
	</div>
	<div class="col-md-6">
		<div class="col-content">
			
		</div>
	</div>
</div>

