<?php
class Event_Handler extends My_Controller {
	/**
	 * Get Start Date of an Event
	 */
	public function getStart($event) {

	}

	/**
	 * Get End Date of an Event
	 */
	public function getEnd($event) {

	}

	/**
	 * Get Person Responsible for an Event
	 */
	public function getResponsible($event) {

	}

	/**
	 * Get Progress of an Event
	 */
	public function getProgress($event) {

	}

}
