<div id="content_parent" class="main">
	<section class="content" id="content1" name="1">
		<h2>Introduction</h2>
	</section>
	<section class="content" id="content2" name="2">
		<h2>Members</h2>
	</section>

	<section class="content" id="content3" name="3">
		<h2>Projects</h2>
		Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
	</section>

	<section class="content" id="content4" name="4">

		<h2>About Us</h2>
		Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
	</section>

	<section class="content" id="content5" name="5">
		<h2>Statement</h2>
		<div class="row">
			<div class="col-md-4">
				<h3>Mission</h3>
				To bridge the gap in service provision between providers and Kenyan public in health care, agriculture and environment through quality delivery systems.
			</div>
			<div class="col-md-4">
				<h3>Vision</h3>
				Excellence in service provision in healthcare, agriculture and environment in the 21st century and beyond.
			</div>
			<div class="col-md-4">
				<h3>Core Values</h3>
				<ul>
					<li>
						<i class="fa fa-shield"></i>Integrity
					</li>
					<li>
						<i class="fa fa-heart"></i>Compassion
					</li>
					<li>
						<i class="fa fa-key"></i>Confidentiality
					</li>
					<li>
						<i class="fa fa-users"></i>Partnership
					</li>
					<li>
						<i class="fa fa-circle-o"></i>Openness
					</li>
					<li>
						<i class="fa fa-phone"></i>Communication
					</li>
					<li>
						<i class="fa fa-laptop"></i>Innovation
					</li>

				</ul>
			</div>
		</div>
	</section>
</div>