<div class="row">
	<div class="col-md-2" id="row-aside">
		<div class="col-content inner">
			<h3>Current Activities</h3>
			<div class="col-content">

			</div>
		</div>
		<div class="col-content inner">
			<h3>Pending Activities</h3>
			<div class="col-content">

			</div>
		</div>
		<div class="col-content inner">
			<h3>Progress</h3>
			<div class="col-content">

			</div>
		</div>
	</div>
	<div class="col-md-10">
		<div id="gantt">
			<?php echo $gantt; ?>
		</div>
	</div>
</div>
<div class="row">
	<div class="col-md-6">
		<div class="col-content">

		</div>
	</div>
	<div class="col-md-6">
		<div class="col-content">

		</div>
	</div>
</div>

