<div class="row">
	<div class="col-md-8">
		<div class="inner">
			<h3>...</h3>
		</div>
	</div>
	<div class="col-md-4">
		<div class="inner">
			<h3>Notifications</h3>
			<ul class="nav nav-pills nav-stacked">
				<li class="active">
					<a href="#"> <span class="badge pull-right">42</span> ... </a>
				</li>
				<li class="">
					<a href="#"> <span class="badge pull-right">42</span> ... </a>
				</li>
			</ul>
		</div>
	</div>
</div>
<div class="row">
	<div class="col-md-4">
		<div class="inner">
			<h4>Add Sub-Program</h4>
			<div id="popular"></div>
		</div>
	</div>
	<div class="col-md-4">
		<div class="inner">
			<h4>...</h4>
			<div id="summary"></div>
		</div>
	</div>
	<div class="col-md-4">
		<div class="inner">

		</div>
	</div>
</div>
