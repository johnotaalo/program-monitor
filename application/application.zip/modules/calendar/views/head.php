<link href="<?php echo base_url().'assets/calendario/styles/calendar.css'?>"  type="text/css" rel="stylesheet" media="all">
<link href="<?php echo base_url().'assets/calendario/styles/custom_2.css'?>"  type="text/css" rel="stylesheet" media="all">
<link href="<?php echo base_url().'assets/styles/font-awesome/css/font-awesome.css'?>"  type="text/css" rel="stylesheet" media="all">
<link href="<?php echo base_url().'assets/styles/bootstrap/bootstrap.css'?>"  type="text/css" rel="stylesheet" media="all">
