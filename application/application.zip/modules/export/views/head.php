<link href="<?php echo base_url().'assets/styles/font-awesome/css/font-awesome.css'?>"  type="text/css" rel="stylesheet" media="all">
<link href="<?php echo base_url().'assets/upload/styles/style.css'?>"  type="text/css" rel="stylesheet" media="all">
<link href="<?php echo base_url().'assets/styles/datatables/jquery.dataTables.css'?>"  type="text/css" rel="stylesheet" media="all">

<link href="<?php echo base_url().'assets/styles/bootstrap/bootstrap.css'?>"  type="text/css" rel="stylesheet" media="all">

