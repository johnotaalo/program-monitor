<?php

class Morbidity_Model extends MY_Controller {

	function __construct() {
		parent::__construct();
	}
}
