<div class="row">
	<div class="col-md-8">
		<div class="inner">
			<h3>...</h3>
		</div>
	</div>
	<div class="col-md-4">
		<div class="inner">
			<h3>...</h3>
		</div>
	</div>

</div>
