<style>
	.datepicker {
		z-index: 1151 !important;
	}
</style>

<div class="row">
	<div class="col-md-9">
		<div class="inner">
			<h3>Update Activities</h3>
			<?php echo $activity_table; ?>
		</div>
	</div>
	<div class="col-md-3">
		<div class="inner">
			<h3>Guide</h3>
			<ul class="guide">
				<li>
					Click on <b>Manual Entry</b> to update data per form.
				</li>
				<li>
					Click in <b>Upload</b> to upload an Excel Sheet in the following <u><i>Format</i></u>:
				</li>
				<table class="table-bordered" style="width:95%">
					<tr style="font-size:1.4em">
						<th>NAMES OF PARTICIPANT</th><th>WORK STATION</th><th>MFL CODE</th><th>CADRE</th><th>ID NUMBER</th>
					</tr>
					<tr style="margin-top:10px;font-size:1.4em">
						<th>MOBILE NUMBER</th><th>EMAIL ADDRESS</th><th>DATES</th>
					</tr>
				</table>
			</ul>

		</div>
	</div>

</div>
<div class="row">
	<div class="col-md-6">
		<div class="inner">
			<h4>...</h4>

		</div>
	</div>

	<div class="col-md-3">
		<div class="inner">
			<h4>...</h4>
		</div>
	</div>
	<div class="col-md-3">
		<div class="inner">
			<h4>...</h4>
		</div>
	</div>
</div>

<script>
	$(document).ready(function() {

	}); 
</script>