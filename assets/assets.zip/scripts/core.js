$(document).ready(function() {
    var theclass;
    $('.fa-expand').click(function() {
        theclass = $(this).parent().parent().parent().attr('class');
        $('.' + theclass).hide();
        $(this).parent().parent().find('.inner').hide();
        $('.inner.mini').show();
        $('.fa-compress').show();
        $('.fa-bar-chart-o').show();
        $('.fa-table').show();
        $(this).parent().find('.fa-table').addClass('selected');
        $(this).parent().find('.fa-bar-chart-o').removeClass('selected');
        $('.fa-expand').hide();
        $(this).parent().parent().parent().show();
        $(this).parent().parent().parent().removeClass('standard-graph');
        $(this).parent().parent().parent().addClass('x-large-graph');
    });
    $('.fa-compress').click(function() {
        $('.' + theclass).show();
        $(this).parent().parent().parent().removeClass('x-large-graph');
        $(this).parent().parent().parent().addClass('standard-graph');
        $('.inner.mini').hide();
        $(this).parent().parent().find('.inner.max').show();
        $('.' + theclass).show();
        $('.fa-compress').hide();
        $('.fa-bar-chart-o').hide();
        $('.fa-table').hide();
        $('.fa-expand').show();
        $(this).parent().parent().find('.mini-graph').empty();
        $(this).parent().parent().find('.mini-graph-2').empty();
        $(this).parent().parent().find('.mini-graph').hide();
        $(this).parent().parent().find('.mini-graph-2').hide();
    });
    $('.fa-bar-chart-o').click(function() {
        $(this).parent().parent().find('.mini-graph').empty();
        $(this).parent().parent().find('.mini-graph-2').empty();
        $(this).parent().find('.fa-bar-chart-o').addClass('selected');
        $(this).parent().find('.fa-table').removeClass('selected');
        $(this).parent().parent().find('.mini').hide();
        $(this).parent().parent().find('.mini-graph').show();
        $(this).parent().parent().find('.mini-graph-2').show();
    });
    $('.fa-table').click(function() {
        $(this).parent().find('.fa-bar-chart-o').removeClass('selected');
        $(this).parent().find('.fa-table').addClass('selected');
        $(this).parent().parent().find('.mini-graph').hide();
        $(this).parent().parent().find('.mini-graph-2').hide();
        $(this).parent().parent().find('.mini').show();
    });
    $('.fa-search').click(function() {
        showSearch();
    });
    $('.search-close').click(function() {
        hideSearch();
    });
    $(document).on('keydown', null, 'ctrl+z', showSearch);
    $(document).on('keydown', null, 'ctrl+x', hideSearch);
});

function runSearch(base_url, function_url) {
    var facilityTable, participantTable;
    $.ajax({
        url: base_url + function_url,
        beforeSend: function(xhr) {
            xhr.overrideMimeType("text/plain; charset=x-user-defined");
        },
        success: function(data) {
            $('#participant_list').empty();
            $('#facility_list').empty();
            var obj = $.parseJSON(data);
            $('#facility_total_existing').text(obj['facility_data']['facility_number_existing']);
            $('#facility_total_trained').text(obj['facility_data']['facility_number_trained']);
            $('#participant_total_trained').text(obj['participant_data']['participant_number_trained']);
            facilityTable = '<table class="dataTable"><thead><th>Facility MFL Code</th> <th>Facility Name</th></thead><tbody> ';
            $.each(obj['facility_data']['facility_list'], function(k, v) {
                facilityTable = facilityTable + '<tr><td>' + v['mfl_code'] + '</td><td>' + v['fac_name'] + '</td></tr>';
            });
            facilityTable = facilityTable + '</tbody></table>';
            $('#facility_list').append(facilityTable);
            $('#participant_total_existing').text(obj['participant_data']['participant_number_existing']);
            $('#participant_total_trained').text(obj['participant_data']['participant_number_trained']);
            participantTable = '<table class="dataTable"><thead><th>Participant Name</th> <th>Facility Name</th></thead><tbody> ';
            $.each(obj['participant_data']['participant_list'], function(k, v) {
                participantTable = participantTable + '<tr><td>' + v['names_of_participant'] + '</td><td>' + v['fac_name'] + '</td></tr>';
            });
            participantTable = participantTable + '</tbody></table>';
            $('#participant_list').append(participantTable);
            $('.dataTable').dataTable({
        "sPaginationType": "full_numbers"
    });
            
            $('.dataTables_filter label input').addClass('form-control');
            $('.dataTables_length label select').addClass('form-control');
            $('#DataTables_Table_0_paginate a').addClass('btn btn-xs btn-default');
            $('#DataTables_Table_0_paginate span a').addClass('btn btn-xs btn-default');
        }
    });
};

function showSearch() {
    $('.fa-search').parent().parent().addClass('active');
    $('.main').animate({
        left: '100%'
    }, 1000);
    $('.search').animate({
        left: '+=100%'
    }, 1000);
    $('.search-close').show();
    $('.fa-search').parent().parent().hide();
};

function hideSearch() {
    $('.fa-search').parent().parent().show();
    $('.search-close').hide();
    $('.search').animate({
        left: '-=100%'
    }, 1000);
    $('.main').animate({
        left: '-=100%'
    }, 1000);
};

function loadGraph(base_url, function_url, container) {
    $('#' + container).load(base_url + function_url);
};
/**
 * [loadGraphSection loops through an array of container IDs to plot the graphs]
 * @param  {[array]} containerArray [description]
 * @param  {[string]} base_url       [description]
 * @param  {[string]} function_url   [description]
 * @param  {[string]} container      [description]
 * @return {[none]}                [description]
 */
function loadGraphSection(base_url, function_url_array, container_array) {
    //alert('Stuff');
    count = 0;
    $.each(container_array, function(index, value) {
        //alert (base_url+function_url_array[count]+'  '+ value);
        loadGraph(base_url, function_url_array[count], value);
        count++;
    });
};